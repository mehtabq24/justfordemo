<?php
    class MailSmsOtp {
        
        function mail($to, $subject, $msg){
    	    $mail = new PHPMailer();
            $mail->IsSMTP();
            $mail->Host = ""; // Your Domain Name
            $mail->SMTPAuth = true;
            $mail->Port = 587;
            $mail->Username = ""; // Your Email ID
            $mail->Password = ""; // Password of your email id
            $mail->From = "";
            $mail->FromName = "";
            $mail->AddAddress ($to);
            $mail->IsHTML(true);
            $mail->Subject = $subject; 
            $mail->Body = $msg;
    		if(!$mail->Send()){
    			return 0;
    		}else{
    			return 1;
    		}
        }


    }
?>